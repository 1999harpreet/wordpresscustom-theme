<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package jagsness-theme
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <h1 style="text-align:center"></h1>
</article><!-- #post-<?php the_ID(); ?> -->