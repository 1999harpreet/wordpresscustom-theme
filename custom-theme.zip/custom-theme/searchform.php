

<form action="/" class="p-5" method="get">
    <input type="text" value="<?php the_search_query(); ?>" class="form-control mb-4" name="s" required>
    <button type='submit' class="w-100 btn btn-success ">SEARCH</button>
</form>                
