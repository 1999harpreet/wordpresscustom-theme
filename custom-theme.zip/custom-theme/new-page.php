<?php

/**
 * * Template Name: new-page.php
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package jagsness-theme
 */

get_header();
?>



<section>
    <div class="banner">
        <!-- <img src="/wp-content/uploads/2022/08/about-building.png" class="img-fluid"> -->

        <?php if (get_field('banner_image')) : ?>
        <img src="<?php the_field('banner_image'); ?>" class="img-fluid" />
        <?php endif; ?>
    </div>
</section>
<section>
    <div class="container">
        <div class="title">
            <h1><?php the_field('about_heading'); ?></h1>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="content">
                    <p>
                        <?php the_field('about_content_left'); ?>
                    </p>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="content">
                    <p>
                        <?php the_field('about_content_right'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

</section>





<section class="blue_back">
    <div class="container">
        <div class="headline">
            <h2><?php the_field('bluesection_heading'); ?></h2>
        </div>
        <div class="row">
            <?php if (have_rows('blue_back')) : ?>
            <?php while (have_rows('blue_back')) : the_row(); ?>

            <div class="col-lg-4">
                <div class="box_section1">
                    <h2><?php if (get_field('blue_back')) : ?>
                        <?php the_sub_field('heading'); ?>
                        <?php endif; ?>
                    </h2>
                    <p><?php if (get_field('blue_back')) : ?>
                        <?php the_sub_field('paragraph'); ?>
                        <?php endif; ?></p>
                </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>


    </div>

    </div>
</section>


<section>
    <div class="container">
        <div class="headline1">
            <h2><?php the_field('image_heading'); ?></h2>
        </div>


        <div class="sec_images">

            <ul>
                <?php if (have_rows('images')) : ?>
                <?php while (have_rows('images')) : the_row(); ?>
                <li><?php if (get_field('images')) : ?>
                    <img src="<?php the_sub_field('image'); ?>" class="img-fluid" />
                    <?php endif; ?>
                </li>
                <?php endwhile; ?>
                <?php endif; ?>
            </ul>
            <!--<ul>
                <li><img src="http://localhost/myfirsttest/wp-content/uploads/2022/08/icon_01_about.png"></li>
                <li><img src="http://localhost/myfirsttest/wp-content/uploads/2022/08/icon_02_about.png"></li>
                <li><img src="http://localhost/myfirsttest/wp-content/uploads/2022/08/icon_03_about.png"></li>
                <li><img src="http://localhost/myfirsttest/wp-content/uploads/2022/08/icon_04_about.png"></li>
                <li><img src="http://localhost/myfirsttest/wp-content/uploads/2022/08/icon_04_about.png"></li>

            </ul>-->
        </div>

</section>


<section class="grey">

    <div class="container">
        <div class="row">


            <div class="col-lg-4">

                <div class="img_sec">
                    <?php if (get_field('certified')) : ?>
                    <img src="<?php the_field('certified'); ?>" class="img-fluid" />
                    <?php endif; ?>
                </div>
            </div>



            <div class="col-lg-8">
                <div class="content _sec">
                    <?php if (have_rows('certified_content')) : ?>
                    <?php while (have_rows('certified_content')) : the_row();?>

                    <h2><?php the_sub_field('heading_certi'); ?></h2>
                    <p><?php the_sub_field('content_certi'); ?></p>
                    <a href="#"><?php the_sub_field('anchor'); ?></a>
                    <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

</section>

<?php get_footer(); ?>