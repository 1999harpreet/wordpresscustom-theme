<?php

/**
 * * Template Name: modco.php
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package jagsness-theme
 */

get_header();
?>


<div class="container-fluid bannerImage">
    <div class="container">
        <h1 class="banner_hdng">Townhouse designs </h1>
        <a href="#" class="banner_btn">Why Choose Us</a>

    </div>
</div>

</div>

<div class="container-fluid middlebar ">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="hdng_bar animate__animated animate__fadeInLeft animate__delay-1s">
                    <?php the_field('heading'); ?>
                </h1>
                <p Class="animate__animated animate__fadeInLeft animate__delay-1s">WE BUILD FASTER THAN ANY OTHER
                    <?php the_field('paragraph'); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid explore">
    <div class="container">
        <div class="row">
            <?php if (have_rows('imgsection')) : ?>
                <?php while (have_rows('imgsection')) : the_row(); ?>


                    <div class="homepic col-lg-6 animate__animated animate__fadeInLeft animate__delay-1s">
                        <?php if (get_field('imgsection')) : ?>
                            <img src="<?php the_sub_field('img'); ?>" class="img-fluid" />
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-6 img_content animate__animated animate__fadeInRight animate__delay-1s">
                        <h1 class="subhdng">
                            <?php if (get_field('imgsection')) : ?>
                                <?php the_sub_field('head'); ?>
                            <?php endif; ?>
                        </h1>
                        <p> <?php if (get_field('imgsection')) : ?>
                                <?php the_sub_field('para'); ?>
                            <?php endif; ?>
                        </p>


                        <a href="#"> <?php if (get_field('imgsection')) : ?>
                                <?php the_sub_field('anchor'); ?>
                            <?php endif; ?>
                        </a>
                        </p>

                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="info container-fluid">
    <div class="container">
        <div class="row">
            <?php if (have_rows('four_section')) : ?>
                <?php while (have_rows('four_section')) : the_row(); ?>
                    <div class="col-lg-3 const_colm">
                        <?php if (get_field('four_section')) : ?>
                            <img src="<?php the_sub_field('icon'); ?>" />
                        <?php endif; ?>
                        <h6><?php if (get_field('four_section')) : ?>
                                <?php the_sub_field('icon_heading'); ?>
                            <?php endif; ?></h6>
                        <p><?php if (get_field('four_section')) : ?>
                                <?php the_sub_field('icon_para'); ?>
                            <?php endif; ?></p>
                    </div>

                    <!--<div class="col-lg-3 const_colm">
                <img src="./assets/images/image-05.png" alt="high end finishes">
                <h6>HIGH-END FINISHES</h6>
                <p>We believe that your home is the biggest investment you will ever make so we offer luxury
                    finishes as standard to ensure you will be proud of your home for the years to come.</p>
            </div>

            <div class="col-lg-3 const_colm">
                <img src="./assets/images/image-06.png" alt="eco-friendly">
                <h6>ECO-FRIENDLY AND SUSTAINABLE</h6>
                <p>We use environmentally preferable building materials and specifications to ensure our
                    environmental impact and your home is as green as possible.</p>
            </div>

            <div class="col-lg-3 const_colm">
                <img src="./assets/images/image-07.png" alt="affordable pricing">
                <h6>AFFORDABLE PRICING</h6>
                <p>As we are part of a bigger group of companies we are able to secure all our building materials at
                    the best rates, allowing us to pass these savings on to you.</p>
            </div>-->
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="container-fluid latest_sec">
    <div class="container">
        <div class="row">
            <h1 class="subhdng">
                THE LATEST
            </h1>
            <div class="three_img col-lg-4">
                <img src="./assets/images/image-08.jpg" alt="lorem ipsum 04">
                <h3 class="n_title"><a href="#"> Lorem Ipsum 04 LS</a></h3>
                <p>what is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                </p>

                <div class="row inner_r">
                    <div class="col-lg-6">
                        <span>04 Aug 2022</span>
                    </div>

                    <div class="col-lg-6">
                        <a href="#">LEARN MORE</a>
                    </div>
                </div>
            </div>

            <div class="three_img col-lg-4">
                <img src="./assets/images/image-08.jpg" alt="lorem ipsum 02">
                <h3 class="n_title"><a href="#"> Lorem Ipsum 03 LS</a></h3>
                <p>what is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                </p>
                <div class="row inner_r">
                    <div class="col-lg-6">
                        <p>04 Aug 2022</p>
                    </div>

                    <div class="col-lg-6">
                        <a href="#">LEARN MORE</a>
                    </div>
                </div>
            </div>

            <div class="three_img col-lg-4">
                <img src="./assets/images/image-08.jpg" alt="lorem ipsum 03">
                <h3 class="n_title"><a href="#"> Lorem Ipsum 02 LS</a></h3>
                <p>what is Lorem Ipsum? Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                </p>


                <div class="row inner_r">
                    <div class="col-lg-6">
                        <span>04 Aug 2022</span>
                    </div>

                    <div class="col-lg-6">
                        <a href="#">LEARN MORE</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>




<?php get_footer(); ?>