<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package jagsness-theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <div id="page" class="site">
        <header class="top">
            <div class="container">
                <div class="topcontent">
                    <span>Language : English French</span>
                </div>
            </div>

        </header>
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-6 left">
                        <a class="navbar-brand" href="#">
                            <?php
                            $custom_logo_id = get_theme_mod('custom_logo');
                            $custom_logo_url = wp_get_attachment_image_url($custom_logo_id, 'full');
                            echo '<img src="' . esc_url($custom_logo_url) . '" alt="Site Logo">';
                            ?>
                            <!-- <img src="<?php echo $custom_logo_url; ?>"> -->
                        </a>
                    </div>

                    <div class="col-6">
                        <div class="contact">
                            <i class="fas fa-phone-alt"></i><span>Call us today at<br>
                                <p>1(800) 268-3509</p>
                            </span>
                        </div>
                    </div>

                </div>
            </div>

        </header>

        <header class="second">
            <div class="col-12">
                <div class="container">
                    <div class="inner">

                        <i class="fas fa-bars"></i>
                        <?php
                        wp_nav_menu(
                            array(
                                'theme_location'   =>     'header',
                                'menu'             =>     'header-menu',
                                'menu_class'       =>     'hs-navBar',
                                'menu_id'          =>     'primary-menu',
                                'container_class'  =>     'hs-navMenu',
                            )
                        )
                        ?>

                        <div class="request">
                            <a href="#">REQUEST A QUOTE</a>
                        </div>
                        <form class="form-inline my-2 my-lg-0">
                            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">

                        </form>
                    </div>

                </div>
            </div>
        </header>


        <!--<header class="second">
            <div class="col-12">
                <div class="inner">

                    <i class="fas fa-bars"></i>
                    <?php
                    wp_nav_menu(
                        array(
                            'theme_location'   =>     'header',
                            'menu'             =>     'header-menu',
                            'menu_class'       =>     'hs-navBar',
                            'menu_id'          =>     'primary-menu',
                            'container_class'  =>     'hs-navMenu',
                        )
                    )
                    ?>
                </div>
            </div>


        </header>-->



        </header>






        <script>
        $(document).ready(function() {
            $("i.fas.fa-bars").click(function() {
                $(".hs-navMenu").toggleClass("main");
            });
        });
        </script>