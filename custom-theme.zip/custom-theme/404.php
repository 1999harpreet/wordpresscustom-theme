<?php
/**
 * The template for displaying 404 pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package jagsness-theme
 */

 get_header(); ?>

	<h1 style="text-align:center;">
        404
    </h1>


<?php get_footer(); ?>