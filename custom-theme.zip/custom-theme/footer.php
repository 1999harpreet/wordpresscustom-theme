<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package jagsness-theme
 */

?>

<footer>

    <div class="container-fluid">
        <div class="container">
            <div class="row foot">
                <?php
                if (is_active_sidebar('mail-widgets')) {
                    dynamic_sidebar('mail-widgets');
                }
                ?>

                <div class="col-lg-5">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="footer_menu">
                                <span>Explore</span>

                                <?php

                                wp_nav_menu(
                                    array(
                                        'theme_location' => 'header',
                                        'menu' => 'footermenu',
                                        'menu_id' => 'secondary-menu',

                                    )
                                )
                                ?>
                                <!-- <ul>
                                    <li><a href="#">About</a></li>
                                    <li><a href="#">Products</a></li>
                                    <li><a href="#">Industries</a></li>
                                    <li><a href="#">Documents</a></li>

                                </ul>-->
                            </div>
                        </div>
                        <div class="col-lg-6">

                            <?php
                            if (is_active_sidebar('test')) {
                                dynamic_sidebar('test');
                            }
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="left">
                            <p>Terms & Conditions | Site Map | Privacy Policy</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="right">
                            <p>© Copyright 2021 | NCI Canada Inc.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



</footer>



</body>

</html>