<?php get_header(); ?>


<main>

    <h1>Front Page</h1>
    <?php the_content(); ?>

</main>

<?php get_footer(); ?>