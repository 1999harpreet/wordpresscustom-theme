<?php get_header(); ?>

<div>
    <h1>Archive Page</h1>
    <?php
    if (is_author()) :
        echo "Author Archive";

    elseif (is_category()) :
        echo "Category Archive";

    elseif (is_day()) :
        echo "Day Archive";

    elseif (is_month()) :
        echo "Month Archive";

    elseif (is_year()) :
        echo "Year Archive";

    endif;
    ?>
</div>

<?php get_footer(); ?>