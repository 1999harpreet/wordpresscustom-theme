
/*---- Get Logo ----*/
<?php
$default_logo = get_bloginfo('template_url') . '/images/logo.png';
$custom_logo_id = get_theme_mod('custom_logo');
$image = wp_get_attachment_image_src($custom_logo_id, 'full');
if (has_custom_logo()) {
    $default_logo = esc_url($image[0]);
}
?>

<img loading='lazy' class='img-fluid' src='<?php echo $default_logo ?>' alt='logo'>

/*---- Get Menu 1 ----*/
<?php
wp_nav_menu(
    array(
        'theme_location' => 'primary_menu',
        'menu_class' => 'navbar-nav',
        'menu_id' => 'navbar-nav_id',
        'container' => 'div',
        'container_class' => 'main-nav',
        'depth' => 3,
    )
)
?>

/*---- Get Menu 2 ----*/
<?php
$location_details = get_nav_menu_locations();
$menu_id = $location_details['primary_menu'];

$menu_item = wp_get_nav_menu_items($menu_id);
?>
<ul class="navbar-nav">
    <?php
    foreach ($menu_item as $value) :
    ?>
        <li class="nav-item"><a href="<?php echo $value->url; ?>" class="nav-link"><?php echo $value->title; ?></a></li>
    <?php
    endforeach;
    ?>
</ul>

/*---- Get Customizer ----*/
<?php echo get_option('footer_logo_setting') ?>
<?php echo get_theme_mod('heading_setting') ?>

/*---- Get Widgets ----*/
if (is_active_sidebar('blog_sidebar')) {
dynamic_sidebar('blog_sidebar');
}

/*---- Create Shortcode ----*/
function shortcode_function(){
require get_template_directory() . '/inc/widgets.php';
}
add_shortcode( 'shortcode_name' , 'shortcode_function' );

/*---- WP_Query ----*/
<?php
$args = array('post_type' => 'post', 'category_name' => 'latest-news', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC',);
$the_query = new WP_Query($args);

if ($the_query->have_posts()) :
    while ($the_query->have_posts()) :
        $the_query->the_post();
    endwhile;
endif;
wp_reset_postdata();
wp_reset_query();
?>

/*---- Get Search Form ----*/
<?php get_search_form(); ?>

/*---- Get Sidebar ----*/
<?php get_sidebar(); ?> 

/*---- Include File In Function File ----*/
ob_start();
require get_template_directory() . '/inc/c_editor_c_widgets.php';
return ob_get_clean();

/*---- Template Call ----*/
/**
* Template Name: Full Width Page
*/

/*---- Last Modify Version  ----*/
fileemtime(plugin_dir_path(__FILE__) . 'FOLDER PATH');

https://github.com/ThingEngineer/PHP-MySQLi-Database-Class#select-query
