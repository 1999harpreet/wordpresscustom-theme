<?php
if (!defined('_T_VERSION')) {
    define('_T_VERSION', '1.0.0');
}

/* ------ Enqueue Styles And Scripts ------ */
function style_script()
{
    wp_enqueue_style('main_css', get_stylesheet_uri(), array(), _T_VERSION, false);
    wp_enqueue_style('fonts_css', get_template_directory_uri() . '/assets/fonts/stylesheet.css', _T_VERSION, false);
    wp_enqueue_style('bootstrap_css', get_template_directory_uri() . '/assets/css/bootstrap_5.2/bootstrap.css', _T_VERSION, false);
    wp_enqueue_style('theme_css', get_template_directory_uri() . '/assets/css/theme-style.css', _T_VERSION, false);

    wp_enqueue_script('bootstrap_js', get_template_directory_uri() . '/assets/js/bootstrap_5.2/bootstrap.js', array(), _T_VERSION, true);
    wp_enqueue_script('theme_js', get_template_directory_uri() . '/assets/js/functions.js', array(), _T_VERSION, true);
}
add_action('wp_enqueue_scripts', 'style_script');


/* ------ Title Support & Post-thumbnails Support & Post-Formats Support ------ */
function custom__theme__setup()
{
    add_theme_support('title_tag');
    add_theme_support('post-thumbnails');
    add_theme_support('post-formats', array('aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat'));

    // Register Theme Custom Logo
    $defaults = array(
        'height'               => 100,
        'width'                => 400,
        'flex-height'          => true,
        'flex-width'           => true,
        'header-text'          => array('site-title', 'site-description'),
        'unlink-homepage-logo' => true,
    );
    add_theme_support('custom-logo', $defaults);
}
add_action('after_setup_theme', 'custom__theme__setup');


/* ------ Revert To Classic Editor & Classic Widgets ------ */
require get_template_directory() . '/inc/c_editor_c_widgets.php';

/* ------ Register Custom Menus ------ */
require get_template_directory() . '/inc/menus.php';

/* ------ Register Widgets ------ */
require get_template_directory() . '/inc/widgets.php';

/* ------ Register Customizer ------ */
require get_template_directory() . '/inc/customizer.php';

/* ------ Admin Login Page Design ------ */
require get_template_directory() . '/inc/login_p_design.php';
