<?php get_header(); ?>

<div>
    <h1>404</h1>
</div>

<?php get_footer(); ?>