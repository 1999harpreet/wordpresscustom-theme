<?php get_header(); ?>

<main>

    <div>
        <h1>Index Page</h1>

        <?php
        if (have_posts()) :
            if (is_home() && !is_front_page()) :
        ?>
                <div>
                    <h1><?php single_post_title(); ?></h1>
                </div>
        <?php
            endif;

            while (have_posts()) :
                the_post();

                get_template_part('template-parts/content', get_post_type());

            endwhile;

            the_posts_navigation();

        else :

            get_template_part('template-parts/content', 'none');

        endif;
        ?>
    </div>

</main>

<?php get_footer(); ?>