<footer>
    <h1>Footer</h1>
</footer>

<?php wp_footer(); ?>
</body>

</html>