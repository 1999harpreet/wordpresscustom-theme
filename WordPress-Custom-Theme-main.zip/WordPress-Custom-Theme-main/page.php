<?php get_header(); ?>

<div>
    <h1>Page</h1>
    <?php the_content(); ?>
</div>

<?php get_footer(); ?>